const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-TjF3g8fi.js","assets/index-BxyjA_pu.js","assets/index-97B0dUBS.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BxyjA_pu.js";const _=r("Network",{web:()=>t(()=>import("./web-TjF3g8fi.js"),__vite__mapDeps([0,1,2])).then(e=>new e.NetworkWeb)});export{_ as Network};
